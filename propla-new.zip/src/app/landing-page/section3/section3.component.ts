import { Component } from '@angular/core';

@Component({
  selector: 'app-section3',
  templateUrl: './section3.component.html',
  styleUrl: './section3.component.scss'
})
export class Section3Component {

}
